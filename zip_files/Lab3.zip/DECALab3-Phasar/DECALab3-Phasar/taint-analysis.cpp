#include "Lab03/IFDSTaintAnalysis.h"

#include "phasar/DataFlow/IfdsIde/Solver/IFDSSolver.h"
#include "phasar/PhasarLLVM/ControlFlow/LLVMBasedICFG.h"
#include "phasar/PhasarLLVM/Pointer/LLVMAliasSet.h"
#include "phasar/PhasarLLVM/TypeHierarchy/DIBasedTypeHierarchy.h"

#include "llvm/Support/WithColor.h"
#include "llvm/Support/raw_ostream.h"

int main(int argc, char **argv) {
  if (argc != 2) {
    llvm::errs() << "USAGE: taint-analysis <IR file>\n";
    return 1;
  }

  psr::LLVMProjectIRDB IR({argv[1]});
  if (!IR)
    return 1;

  const auto *EntryPointFun = IR.getFunctionDefinition("main");
  if (!EntryPointFun) {
    llvm::WithColor::error()
        << "target program does not contain required entry point 'main'!\n";
    return 1;
  }

  psr::DIBasedTypeHierarchy TH(IR);
  psr::LLVMAliasSet Aliases(&IR);
  psr::LLVMBasedICFG ICF(&IR, psr::CallGraphAnalysisType::RTA, {"main"}, &TH,
                         &Aliases);

  lab03::IFDSTaintAnalysis TaintProblem(&IR, &Aliases, {"main"});
  auto Results = psr::solveIFDSProblem(TaintProblem, ICF);
  TaintProblem.emitTextReport(Results);
}
