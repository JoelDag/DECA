# Lab 03

## Setup

Supported Platforms:

* Linux (preferrably a Debian-based distribution): The most stable platform for PhASAR
* Windows: Use WSL 2, or a VM
* Mac: Might work natively, else use a VM or Docker

You'll need the following dependencies installed:

```bash
sudo apt install clang-15 llvm-15-dev libllvm15 libboost-graph-dev ninja-build
```

## How to build the project

```bash
# Assuming you are in the project's ROOT directory
mkdir -p build
cd build
# Ninja is not strictly necessary, but we strongly recommend it over GNU Makefiles
# Note: The first invocation of cmake will download PhASAR, so it might take a while
# Note: clang might be named differently on your system, e.g., clang-15, clang++-15
CC=clang CXX=clang++ cmake -G Ninja ..
ninja
```

## How to run the tests

```bash
# Assume, you are in the project's build folder that you created above

# Run all tests
ctest
# If tests failed, the output will point you to a LastTest.log containing more informaion

# Run individual tests
cd unittests/
./IFDSTaintAnalysisTest
```

You can also use the command-line tool `taint-analysis` to analyze arbitrary LLVM-15 IR files.
It is located directly within the build folder.

```bash
# Example from build folder:
./taint-analysis ./target/sql-program-test-1_cpp_dbg.ll
```

## How to clean

To cleanup all build artifacts, it is recommended to *not* just delete the build folder's contents.
This would require you to re-download PhASAR on the next configure.
Instead run this:

```bash
# Assume, you are in the project's build folder
ninja clean
```

To completely reconfigure with invalidating the cache:

```bash
CC=clang CXX=clang++ cmake -G Ninja --fresh ..
```
