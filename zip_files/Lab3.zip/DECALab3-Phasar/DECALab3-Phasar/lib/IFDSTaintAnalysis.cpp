#include "Lab03/IFDSTaintAnalysis.h"

#include "phasar/PhasarLLVM/ControlFlow/LLVMBasedCFG.h"
#include "phasar/PhasarLLVM/DataFlow/IfdsIde/LLVMZeroValue.h"

using namespace lab03;

IFDSTaintAnalysis::IFDSTaintAnalysis(const psr::LLVMProjectIRDB *IRDB,
                                     psr::LLVMAliasInfoRef Aliases,
                                     std::vector<std::string> EntryPoints)
    : IFDSTabulationProblem(IRDB, std::move(EntryPoints),
                            psr::LLVMZeroValue::getInstance()),
      Aliases(Aliases) {}

auto IFDSTaintAnalysis::getNormalFlowFunction(n_t Curr,
                                              n_t Succ) -> FlowFunctionPtrType {
  // TODO: provide implementation
  return identityFlow();
}

auto IFDSTaintAnalysis::getCallFlowFunction(n_t CallSite, f_t DestFun)
    -> FlowFunctionPtrType {
  // TODO: provide implementation
  return identityFlow();
}

auto IFDSTaintAnalysis::getRetFlowFunction(n_t CallSite, f_t CalleeFun,
                                           n_t ExitStmt,
                                           n_t RetSite) -> FlowFunctionPtrType {
  // TODO: provide implementation
  return identityFlow();
}

auto IFDSTaintAnalysis::getCallToRetFlowFunction(n_t CallSite, n_t RetSite,
                                                 llvm::ArrayRef<f_t> Callees)
    -> FlowFunctionPtrType {
  // TODO: provide implementation
  return identityFlow();
}

auto IFDSTaintAnalysis::getSummaryFlowFunction(n_t CallSite, f_t DestFun)
    -> FlowFunctionPtrType {
  // TODO: provide implementation
  return nullptr;
}

auto IFDSTaintAnalysis::initialSeeds() -> psr::InitialSeeds<n_t, d_t, l_t> {
  psr::InitialSeeds<n_t, d_t, l_t> Seeds;

  psr::LLVMBasedCFG C;
  addSeedsForStartingPoints(EntryPoints, IRDB, C, Seeds, getZeroValue(),
                            psr::BinaryDomain::BOTTOM);

  // TODO: Add more starting facts here (see task description)

  return Seeds;
}

bool IFDSTaintAnalysis::isZeroValue(d_t FlowFact) const noexcept {
  return psr::LLVMZeroValue::isLLVMZeroValue(FlowFact);
}

void IFDSTaintAnalysis::emitTextReport(
    const psr::SolverResults<n_t, d_t, psr::BinaryDomain> &SR,
    llvm::raw_ostream &OS) {
  // TODO: provide a more sensible implementation

  psr::LLVMBasedCFG CFG;
  SR.dumpResults(CFG, OS);
}
