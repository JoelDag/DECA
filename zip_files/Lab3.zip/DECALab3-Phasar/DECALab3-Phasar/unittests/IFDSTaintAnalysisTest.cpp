#include "Lab03/IFDSTaintAnalysis.h"
#include "phasar/DataFlow/IfdsIde/Solver/IFDSSolver.h"
#include "phasar/PhasarLLVM/ControlFlow/LLVMBasedICFG.h"
#include "phasar/PhasarLLVM/DB/LLVMProjectIRDB.h"
#include "phasar/PhasarLLVM/Pointer/LLVMAliasSet.h"
#include "phasar/PhasarLLVM/TypeHierarchy/DIBasedTypeHierarchy.h"
#include "phasar/PhasarLLVM/Utils/LLVMIRToSrc.h"

#include "llvm/ADT/Twine.h"

#include "gtest/gtest.h"

#include <set>

namespace {
class TaintAnalysisTest : public ::testing::Test {
protected:
  void runAndCompare(const llvm::Twine &IRFile, std::set<uint32_t> LeakLines) {
    psr::LLVMProjectIRDB IRDB(LAB03_PATH_TO_LL_FILES + IRFile);
    ASSERT_TRUE(IRDB.isValid());
    psr::DIBasedTypeHierarchy TH(IRDB);
    psr::LLVMAliasSet Aliases(&IRDB);
    psr::LLVMBasedICFG ICF(&IRDB, psr::CallGraphAnalysisType::RTA, {"main"},
                           &TH, &Aliases);

    lab03::IFDSTaintAnalysis TaintProblem(&IRDB, &Aliases, {"main"});
    psr::solveIFDSProblem(TaintProblem, ICF);

    for (const auto &[LeakInst, _] : TaintProblem.getLeaks()) {
      auto Line = psr::getLineFromIR(LeakInst);
      EXPECT_TRUE(LeakLines.erase(Line))
          << "Did not expect to find a leak at line " << Line;
    }

    for (auto Line : LeakLines) {
      ADD_FAILURE() << "Did not find leak at line " << Line;
    }
  }
};

TEST_F(TaintAnalysisTest, sql_program_test_1) {
  runAndCompare("sql-program-test-1_cpp_dbg.ll", {31});
}

TEST_F(TaintAnalysisTest, sql_program_test_2) {
  runAndCompare("sql-program-test-2_cpp_dbg.ll", {39});
}

TEST_F(TaintAnalysisTest, sql_program_test_3) {
  runAndCompare("sql-program-test-3_cpp_dbg.ll", {/*empty*/});
}

TEST_F(TaintAnalysisTest, sql_program_test_4) {
  runAndCompare("sql-program-test-4_cpp_dbg.ll", {40});
}

TEST_F(TaintAnalysisTest, sql_program_test_5) {
  runAndCompare("sql-program-test-5_cpp_dbg.ll", {/*empty*/});
}

TEST_F(TaintAnalysisTest, sql_program_test_6) {
  runAndCompare("sql-program-test-6_cpp_dbg.ll", {42});
}

TEST_F(TaintAnalysisTest, sql_program_test_7) {
  runAndCompare("sql-program-test-7_cpp_dbg.ll", {/*empty*/});
}

} // namespace
