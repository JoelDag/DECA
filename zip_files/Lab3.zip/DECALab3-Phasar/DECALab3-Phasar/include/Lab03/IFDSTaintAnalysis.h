#pragma once

#include "phasar/DataFlow/IfdsIde/IFDSTabulationProblem.h"
#include "phasar/PhasarLLVM/DB/LLVMProjectIRDB.h"
#include "phasar/PhasarLLVM/Domain/LLVMAnalysisDomain.h"
#include "phasar/PhasarLLVM/Pointer/LLVMAliasInfo.h"

namespace lab03 {

struct TaintAnalysisDomain : psr::LLVMAnalysisDomainDefault {
  // TODO: For Exercise 5, adapt this to use your own flow-fact type:
  // using d_t = ...;
};

class IFDSTaintAnalysis
    : public psr::IFDSTabulationProblem<TaintAnalysisDomain> {

public:
  using IFDSTabProblemType = psr::IFDSTabulationProblem<TaintAnalysisDomain>;
  using typename IFDSTabProblemType::d_t;
  using typename IFDSTabProblemType::f_t;
  using typename IFDSTabProblemType::n_t;

  IFDSTaintAnalysis(const psr::LLVMProjectIRDB *IRDB,
                    psr::LLVMAliasInfoRef Aliases,
                    std::vector<std::string> EntryPoints = {"main"});

  ~IFDSTaintAnalysis() override = default;

  FlowFunctionPtrType getNormalFlowFunction(n_t Curr, n_t Succ) override;

  FlowFunctionPtrType getCallFlowFunction(n_t CallSite, f_t DestFun) override;

  FlowFunctionPtrType getRetFlowFunction(n_t CallSite, f_t CalleeFun,
                                         n_t ExitStmt, n_t RetSite) override;

  FlowFunctionPtrType
  getCallToRetFlowFunction(n_t CallSite, n_t RetSite,
                           llvm::ArrayRef<f_t> Callees) override;

  FlowFunctionPtrType getSummaryFlowFunction(n_t CallSite,
                                             f_t DestFun) override;

  psr::InitialSeeds<n_t, d_t, l_t> initialSeeds() override;

  bool isZeroValue(d_t FlowFact) const noexcept override;

  void emitTextReport(const psr::SolverResults<n_t, d_t, psr::BinaryDomain> &SR,
                      llvm::raw_ostream &OS = llvm::outs()) override;

  [[nodiscard]] const auto &getLeaks() const noexcept { return Leaks; }

private:
  psr::LLVMAliasInfoRef Aliases{};

  // Use this map to collect the leaks your analysis detects.
  std::map<n_t, std::set<d_t>> Leaks;
};
} // namespace lab03
